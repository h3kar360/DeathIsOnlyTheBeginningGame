using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Shooting : MonoBehaviour
{
    public GameObject bullet;
    public float shootingCoolDown;
    public float shootSpeed;
    public Transform gun;

    bool isShooting;

    // Start is called before the first frame update
    void Start()
    {
        isShooting = false;
    }

    // Update is called once per frame
    void Update()
    {       
        if (Input.GetKeyDown(KeyCode.J) && !isShooting)
        {
            StartCoroutine(coolDownNShoot());
        }
               
    }

    IEnumerator coolDownNShoot()
    {
        int vector()
        {
            if(transform.localScale.x < 0f)
            {
                return -1;
            }
            else
            {
                return 1;
            }
        }

        isShooting = true;
        GameObject bulletRb = Instantiate(bullet, gun.position, Quaternion.identity);
        bulletRb.GetComponent<Rigidbody2D>().velocity = new Vector2(shootSpeed * vector() * Time.fixedDeltaTime, 0f);

        yield return new WaitForSeconds(shootingCoolDown);
        Destroy(bulletRb);
        isShooting = false;
    }
}
