using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FollowPlayerNKill : MonoBehaviour
{
    public HealthSystem playerHp;
    public Transform player;
    public float enemySpeed;
    public float minDist;
    float dmg = 5f;
    float timer = 1f;
    float intimer;

    // Start is called before the first frame update
    void Start()
    {
        intimer = timer;
    }

    // Update is called once per frame
    void Update()
    {
        float dist = Vector3.Distance(player.position, transform.position);

        if (dist > minDist)
        {
            transform.position = Vector3.MoveTowards(transform.position, player.position, enemySpeed * Time.deltaTime);
        }

        //if(dist < minDist)
        //{
        //    ATK();
        //}
    }

    //void ATK()
    //{
    //    timer -= Time.deltaTime;
    //    if (timer <= 0)
    //    {
    //        playerHp.TakeDmg(dmg);
    //        timer = intimer;
    //    }
    //}
}
