using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player_Movement : MonoBehaviour
{
    Rigidbody2D rb;

    public float speed;
    public bool isGrounded;

    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {
        float movement = Input.GetAxis("Horizontal");

        rb.velocity = new Vector2(movement * speed, rb.velocity.y);

        if ((Input.GetKeyDown(KeyCode.Space) || Input.GetKeyDown(KeyCode.W)) && isGrounded)
        {
            rb.velocity = new Vector2(rb.velocity.x, speed);
            isGrounded = false;
        }

        //charflip
        Vector2 playerScale = transform.localScale;

        if(movement < 0)
        {
            playerScale.x = -1;
        }
        else if(movement > 0)
        {
            playerScale.x = 1;
        }

        transform.localScale = playerScale;

        Physics2D.IgnoreLayerCollision(6, 6);
    }

    private void OnCollisionEnter2D(Collision2D player)
    {
        if (player.gameObject.name == "platform")
            isGrounded = true;
    }
}
