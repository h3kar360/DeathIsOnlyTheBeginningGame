using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class HealthSystem : MonoBehaviour
{
    public Image hpBar;
    public float hpAmmount;

    float initialHp;

    private void Start()
    {
        initialHp = hpAmmount;
    }

    private void Update()
    {
        if (hpAmmount <= 0)
        {
            Application.LoadLevel(Application.loadedLevel);
        }
    }

    public void TakeDmg(float dmg)
    {
        hpAmmount -= dmg;
        hpBar.fillAmount = hpAmmount / initialHp;
    }
}
